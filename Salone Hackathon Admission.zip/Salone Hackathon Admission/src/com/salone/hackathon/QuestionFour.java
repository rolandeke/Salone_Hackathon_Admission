package com.salone.hackathon;

import java.io.*;
import java.util.Scanner;

public class QuestionFour {
    public static void main(String[] args) throws IOException {
        File file = new File("helloworld.txt");


        System.out.println(readSpecificLine(file,1));

    }






    public static String readSpecificLine(File inputFile, int position) throws IOException {
            FileReader fileReader = new FileReader(inputFile);
            BufferedReader bufferedReader = new BufferedReader(fileReader);
            String outputLine = "";
            int numberOfLines = readLines(inputFile);
            int line = 1;

            if(position <= 0){

                return "Only Positive Integers Allowed";
            }else if(position > numberOfLines){

                return "Number is out of bounds";
            }
            else{
                    do{
                        if(line == position){
                            outputLine = bufferedReader.readLine();
                        }

                        line++;
                    }while (bufferedReader.readLine() != null);

            }

           return outputLine;
    }

    private static int readLines(File inputFile) throws IOException {

        FileReader fileReader = new FileReader(inputFile);
        BufferedReader bufferedReader = new BufferedReader(fileReader);

        int lines = 0;

        while(bufferedReader.readLine() != null){
            lines++;
        }
        bufferedReader.close();

        return lines;
    }


}
