package com.salone.hackathon;

public class QuestionOne {

    public static void main(String[] args) {
        String[] words = {"hello","world","hi","bye"};


        System.out.println(findLongestWord(words));
    }

    public static  String findLongestWord(String[] input){

        String longestWord = input[0];

        for(int i = 0; i < input.length; i++){

            if(input[i].length() > longestWord.length()){
                longestWord = input[i];
            }
        }

        return longestWord;
    }
}
