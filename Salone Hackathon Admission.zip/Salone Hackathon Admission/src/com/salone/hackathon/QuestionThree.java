package com.salone.hackathon;

import java.util.*;

import static java.util.Map.entry;

public class QuestionThree {

    public static void main(String[] args) {
       Map<String, String> words = new HashMap<>(){{
          put("key","value");
          put("ab","hi there");
          put("we","say what");
       }};

       sortHashMap(words);


    }


    public static void sortHashMap(Map<String, String> inputMap){

        ArrayList<String> sortedKeys = new ArrayList<>(inputMap.keySet());
        Collections.sort(sortedKeys);

        for(String keys: sortedKeys){
            System.out.println(keys + " " + inputMap.get(keys));
        }
    }



}
