package com.salone.hackathon;

public class QuestionTwo {

    public static void main(String[] args) {

        int[] num = {1,2,3,4,5,7};
        System.out.print("[");
        findOdds(num);
        System.out.print("]");


    }


    public static void findOdds(int[] input){

        for(int i : input){
            if(i % 2 != 0){
                System.out.print(i + " ");
            }
        }
    }


}
